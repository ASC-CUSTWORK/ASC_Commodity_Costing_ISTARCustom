<%@ Page Language="C#" MasterPageFile="~/MasterPages/FormView.master" AutoEventWireup="true" ValidateRequest="false" CodeFile="PO303001.aspx.cs" Inherits="Page_PO303001" Title="Untitled Page" %>
<%@ MasterType VirtualPath="~/MasterPages/FormView.master" %>

<asp:Content ID="cont1" ContentPlaceHolderID="phDS" Runat="Server">
	<px:PXDataSource ID="ds" runat="server" Visible="True" Width="100%"
        TypeName="ASCISTARCustom.PO.ASCiStarDutyFreightMaint"
        PrimaryView="ASCiStarDutyFreightView"
        >
		<CallbackCommands>
			<px:PXDSCallbackCommand Name="First" Visible="False" />
			<px:PXDSCallbackCommand Name="Previous" Visible="False" />
			<px:PXDSCallbackCommand Name="Next" Visible="False" />
			<px:PXDSCallbackCommand Name="Last" Visible="False" />
			<px:PXDSCallbackCommand Name="CopyPaste" Visible="False" />
			<px:PXDSCallbackCommand Name="Save" Visible="True" />
			<px:PXDSCallbackCommand Name="Cancel" Visible="True" />
			<px:PXDSCallbackCommand Name="Insert" Visible="False" />
			<px:PXDSCallbackCommand Name="Delete" Visible="False" /></CallbackCommands>
	</px:PXDataSource>
</asp:Content>
<asp:Content ID="cont2" ContentPlaceHolderID="phF" Runat="Server">
	<px:PXGrid SyncPosition="True" KeepPosition="True" Height="150px" SkinID="Primary" Width="100%" AllowAutoHide="false" DataSourceID="ds" runat="server" ID="CstPXGrid1">
		<Levels>
			<px:PXGridLevel DataMember="ASCiStarDutyFreightView" >
				<Columns>
					<px:PXGridColumn DataField="HSTariffCode" Width="140" ></px:PXGridColumn>
					<px:PXGridColumn DataField="CountryCode" Width="220" ></px:PXGridColumn>
					<px:PXGridColumn DisplayFormat="##0.00" DataField="DutyPercent" Width="100" ></px:PXGridColumn>
					<px:PXGridColumn DataField="EffectiveDate" Width="90" /></Columns></px:PXGridLevel></Levels>
		<AutoSize Enabled="True" />
		<AutoSize Container="Window" />
		<AutoSize MinHeight="600" /></px:PXGrid></asp:Content>

